#include "main.h"

void all_init(void);
void send_data(void);
void clear_lcd(void);
void lcd_init(void);
void lcd_datasheet_main(void);
